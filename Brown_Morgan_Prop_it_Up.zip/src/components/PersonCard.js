import React from "react";
const PersonCard = (props) => {
    const { firstName, lastName, age, hairColor} = props;
    return(
        <div>
            <h2> {lastName}, {firstName}</h2>
            <span>Age: {age}</span>
            <span>Hair Color: {hairColor}</span>
        </div>
    )
}

export default PersonCard;